var maps = {
    "singleplayer":[
        {
            "name":"Introduction",
            "briefing": "In this level you will learn how to pan across the map.\n\nDon't worry! We will be implementing more features soon.",            
            
            /* Map Details */
            "mapImage":"images/maps/level-one-debug-grid.png",            
            "startX":4,
            "startY":4,
            
        },
    ]
};
