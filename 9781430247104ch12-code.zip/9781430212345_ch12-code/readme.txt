Last Colony
-----------

Multiplayer Setup
-----------------

i) Install Node.js from http://nodejs.org/. 
ii) Install WebSocket-Node using command: npm install websocket
iii) Start server in js/server.js using command: node js/server.js
iv) Open index.html in HTML5 enabled web browser

Credits
--------

Artwork:

i) "Hard Vaccum" Artwork and Game Sprites by Daniel Cook (http://www.lostgarden.com/)
ii) Artwork from Open Game Art (opengameart.org)
	a) Thief Portrait by Zeldyn (http://opengameart.org/content/thief-portrait-female)
	b) Jacob Portrait by Gaspard (http://opengameart.org/content/four-post-apocalyptic-portraits)
	c) Priest Portrait by Zeldyn (http://opengameart.org/content/priest-portrait-female)

Sounds:

All sounds from Free Sound (http://www.freesound.org/)
